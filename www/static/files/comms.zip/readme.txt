TeamFortress Communications Configs, Attack and Defence by bliP
Web: http://nisda.net
Email: scrag [at] nisda [dot] net
IRC: #nzgames irc.enterthegame.com
Released: 2002-02-04

Made for ZQuake build 749 and above, may need extra editing for other clients/proxies.
You can get the sounds from somewhere, place them in quake\id1\sound\reports

1) Place att.cfg and def.cfg in your quake\id1 directory then open them in any text
   editor (notepad) and change NAME to your name.
   eg.
   from: //bind ? "say_team ~reports/responding.wav$\$B �NAME� responding $B #d"
   to:   //bind ? "say_team ~reports/responding.wav$\$B �blip� responding $B #d"

2) Uncomment (remove the // in front of line) the messages you'd like and change the
   ? to the key you want to use.
   eg.
   from: //bind ? "say_team ~reports/responding.wav$\$B �blip� responding $B #d"
   to:   bind x "say_team ~reports/responding.wav$\$B �blip� responding $B #d"

3) Either start QuakeWorld and type the line or add them to another cfg:
   For attack config:
    exec att.cfg
   For defence config:
    exec def.cfg
   
Other settings you might need:
 cl_parseSay 1
 cl_parseFunChars 1
 cl_parseWhiteText 1

Breakdown of what parts of the line mean:
 bind x "say_team ~reports/responding.wav$\$B �blip� responding $B #d"

  bind x: Binds whatever is after it to the key x.
  say_team: Displays team message.
  ~reports/responding.wav: The SoundTrigger.
   ~ is the trigger and reports/responding.wav is the sound to play.
   To work, the SoundTrigger has to be at the end of the line or have a $\ after it.
     eg.
     say_team ~reports/responding.wav$\
     say_team ~reports/responding.wav
  $\: Hides all text before it
  $B: Led (if you have ocrana pak)
  �: Dot before and after name
  responding: Text
  #d: Message filter
  Better explanations can be found in Qizmo, NFProxy, Cheapo and ZQuake help files.

