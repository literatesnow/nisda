MapEx v1.1 - Copyright (C) 2003 bliP
Web: http://nisda.net
Email: scrag [at] nisda [dot] net
IRC: #nzgames irc.enterthegame.com

Description:
From a list of maps, collects all the required model and sound files from the
quake directory and compresses them either individually or together.

Usage:
mapex.exe [-f in_file] [-o out_directory] [-t tmp_directory]
          [-m [single|all]] [-a archive_program] [-p archive_parameters]

-f in_file: input file, plain text list of maps, each map on a new line
-o out_directory: directory to place finished files
-t tmp_directory: temporary working directory
-m single|all: use archive program on individual maps or all maps
-a archive_program: compression program, full path and enclose with quotes (")
-p archive_parameters: program's parameters, enclose with quotes (")
  If used, the following variables will be replaced:
    %outdir - out_directory
    %file - map name (minus extension)
    %tmpdir - tmp_directory

Out/temp directories and archive program/parameters can be set in mapex.ini,
this example uses the WinZip Command Line Addon (from http://www.winzip.com)
with the maximum compression settings (ex) and recurse directory (rp) option:
  [main]
  out_directory=c:\mapout
  tmp_directory=c:\maptemp
  base_directory=c:\quake\fortress
  archive_program=c:\progra~1\winzip\wzzip.exe
  archive_parameters=-ex -rp %outdir\%file.zip %tmpdir\*.*

Example:
  maplist.txt:
    amth1.bsp
    2fort5r.bsp

Using the list of maps in maplist.txt and the above mapex.ini, compress each
map individually:

mapex.exe -f maplist.txt -m single

Please send all questions, bug reports, comments and suggestions
to the email address provided above.

Disclaimer:
ANY USE BY YOU OF THE SOFTWARE IS AT YOUR OWN RISK. THE SOFTWARE IS
PROVIDED FOR USE "AS IS" WITHOUT WARRANTY OF ANY KIND. THIS SOFTWARE
IS RELEASED AS "FREEWARE". REDISTRIBUTION IS ONLY ALLOWED IF THE
SOFTWARE IS UNMODIFIED, NO FEE IS CHARGED FOR THE SOFTWARE, DIRECTLY
OR INDIRECTLY WITHOUT THE EXPRESS PERMISSION OF THE AUTHOR.
