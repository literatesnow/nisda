The Large and Overcomplicated(tm) QuakeWorld TeamFortress CFG by bliP
Web: http://nisda.net
Email: scrag [at] nisda [dot] net
IRC: #nzgames irc.enterthegame.com
Released: 2003-09-08

Use with fuhquake >= 0.28, should work with zquake (use tfcomms.cfg instead
of tfcomms.cfg), doesn't work every well (if at all) with mqwcl and variants.

If you _really_ want to use the entire cfg then backup your quake directory
then extract this zip into quake/

In my infinite wisdom I changed all TF aliases to the impulse they point at.
So, bind "y" "impulse 173", is like bind "y" "reload".
Don't ask what I was thinking.

Files:
pak2.pak - (id1) contains the charset with crosshair I made and the brighter
  palette.lmp which was from the dark TNT2 which I used to have
server.cfg - (id1) cfg for my test dedicated server
all config.cfg - made them read-only so quake couldn't write to them

Known Issues:
If you're spy then change class, 1-9 are still bound to change skin
doesn't really matter because it does the impulse last anyway.

Have fun understanding/using/ripping this CFG!
Good luck (you'll probably need it)

Console:

* change class
1 - change to scout
2 - change to sniper
3 - change to soldier
4 - change to demoman
5 - change to medic
6 - change to hwguy
7 - change to pyro
8 - change to spy
9 - change to engineer

* took/death messages
sm0 - silent took powerup/death (default)
sm1 - spam took powerup, silent death
sm2 - spam took powerup and death

* fuhquake
fq0 - turn off effects
fq1 - turn on effects

* servers
c <ip> - connect
d - disconnect
r - reconnect
p <pw> - password
s <0/1> - spectator
gs - go spectator
gp - go player
+ see id1\settings.cfg for server alias' and ips
+ c $ipgn will connect to ipgn

* other
alias frj nofrj - turn off frj

Keys:

* standard
a - prime gren 1, s to throw
s - prime gren 1, a to throw
r - forward
f - back
d - sleft
g - sright
q - id
w - discard/flaginfo
e - drop flag
j - medic
k - dropammo
l - inv
y - reload
h - primary weapon
b - secondary weapon
t - tertiary weapon
[ - say all
] - team say
space - jump
mouse1 - attack
mouse2 - special
mouse3 - nothing
mwheelup - zoom in
mwheeldown - zoom out
del - you're never going to take me alive!
home - screeny
f9 - users
f10 - query/timeleft
pause - qizmo menu on/off
' - topcolour

* demoman
h - pipe
b - normal gren
mouse2 - det pipes
o - det5
i - det20
u - det50
p - det255
n - det10
m - det30
, - det40
. - det60

* engineer
h - shotty
b - railgun
t - repair gun
mwheelup - add ammos to gun
mwheeldown - upgrade gun
mouse2 - build gun
shift - detdispenser
n/m - build dispenser
,/. - det sentry
z - rotate gun

* hwguy
h - asscan
b - shotty
t - single shotty

* medic
h - super nailgun
b - shotty
t - single shotty
mouse2 - bioweapon

* pyro
h - incindary cannon
b - flame thrower
t - single shotty

* scout
h - nailgun
b - single shotty
mouse2 - autoscan

* sniper
h - rifle
b - auto rifle
mouse2 - zoom in/out

* soldier
h - rocket launcher
b - shotty
t - single shotty
mouse2 - frj/nofrj

* spy
1 - disguise as scout
2 - disguise as sniper
3 - disguise as soldier
4 - disguise as demoman
5 - disguise as medic
6 - disguise as hwguy
7 - disguise as pyro
8 - disguise as spy (hehe)
9 - disguise as engineer
t - change colour to enemy
u - colour to blue
i - colour to red
o - colour to yellow
p - colour to green
h - shotty
b - sleep
mouse2 - sfeign
mwheelup - nailgun
mwheeldown - backstabber

* comms (standard)
+ push backspace and any incoming key to turn it into outgoing call
+ mouse4 and mouse5 large and small thumb buttons on intellimouse explorer
f1 - incoming spiral
f2 - incoming ramps
f3 - incoming lift
f4 - incoming high
f5 - incoming water
f6 - incoming to flag
f7 - spy alert
f8 - waiting for cap
f11 - our flag here
f12 - enemy flag there
kp_1 - clear
kp_2 - need stuff
kp_3 - piper dead
kp_4 - away from pos
kp_5 - help
kp_6 - cancel
kp_7 - go!
kp_8 - reset
kp_9 - wait
kp_slash - got cap
kp_plus - okay
kp_enter - my stats (health, armour, location, powerups)
kp_ins - enemy camping my spot (well6 roof)
kp_del - cussed/tropped/disabled
/ - i'm goin' up
uparrow - wtf did you drop the flag?
downarrow - omg tell us where our flag is so i can defend it ffs
leftarrow - doh, i teamkilled our gun again
rightarrow - after getting mown down 52 times i finally killed their sentry gun
mouse4 (ins) - my stats (health, armour, location, powerups)
mouse5 (end) - what i'm looking at
