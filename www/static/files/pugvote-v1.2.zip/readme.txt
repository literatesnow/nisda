Pug Vote v1.2 - Copyright (C) 2003 bliP
Web: http://nisda.net
Email: scrag [at] nisda [dot] net

Description:
This is a pug map voting script for mIRC.
Inspired by redfox's pugvote script.

Install:
 put pugvote.mrc and pugvote.ini in your mIRC directory
 type /load -rs pugvote.mrc
 then /pugvote to use

Uninstall:
 type /unload -rs pugvote.mrc
 delete pugvote.mrc and pugvote.ini

Example pugvote.ini
 [maps]
 list1=2f5,b4,mb,w6,hc
 list2=2f5,tf2k,r2,b4,32s
 list3=32s,cz,xl,dis,2f5