Arc v1.5 - Copyright (C) 2001-2007 bliP
Web: http://nisda.net
Email: scrag [at] nisda [dot] net
IRC: #nzgames irc.enterthegame.com
Compiled: v1.2: 2001-10-25, v1.3: 2001-12-07, v1.5: 2007-01-20

Description:
Send single/many Rcon commands to a QuakeWorld server.

Usage:
Single commands:
1) Enter server details in the Rcon@Server:Port box.
   Example: foo@127.0.0.1:27500 (where foo is the Rcon)
2) Type any valid Rcon command to send to the server in the command
   box and hit enter.
   Example: status, listip etc.

Many commands:
1) Enter server details in the Rcon@Server:Port box.
   Example: foo@127.0.0.1:27500
2) Click File.., choose a cfg then click open.
   Example cfg: duel.cfg
     timelimit 0
     fraglimit 0
     map dm6
     maxclients 6
     maxspectators 12
     password none
     spectator_password none
     hostname "Duel Server (dm6)"
   Note: Every line of the cfg is read, "rcon rcon_pwd" added and sent to
   the server.

To add servers to Rcon@Server:Port box, create a plain text file in
Arc directory called servers.
  Example servers file:
    foo@localhost:27500
    foo@192.168.0.23:29000
    foo@10.0.0.1:27501

Please send all questions, bug reports, comments and suggestions
to the email address provided above.

Thanks to Shoyu for ideas/tesing.

Disclaimer:
ANY USE BY YOU OF THE SOFTWARE IS AT YOUR OWN RISK. THE SOFTWARE IS
PROVIDED FOR USE "AS IS" WITHOUT WARRANTY OF ANY KIND. THIS SOFTWARE
IS RELEASED AS "FREEWARE". REDISTRIBUTION IS ONLY ALLOWED IF THE
SOFTWARE IS UNMODIFIED, NO FEE IS CHARGED FOR THE SOFTWARE, DIRECTLY
OR INDIRECTLY WITHOUT THE EXPRESS PERMISSION OF THE AUTHOR.
