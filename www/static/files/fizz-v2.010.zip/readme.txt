Fizz - Copyright (C) 2001-2003 bliP
Web: http://nisda.net
Email: spawn [at] nisda [dot] net
IRC: #nzgames irc.enterthegame.com

Fizz is a game server browser.

Install: Unzip and run fizz.exe
Uninstall: Run fizz.exe -reset, delete fizz.* and server.fzs
Help: Hopefully fizz.hlp is useful, complete with its spelling mistakes.

Please send all questions, bug reports, comments and suggestions
to the email address provided above.

Disclaimer:
ANY USE BY YOU OF THE SOFTWARE IS AT YOUR OWN RISK. THE SOFTWARE IS
PROVIDED FOR USE "AS IS" WITHOUT WARRANTY OF ANY KIND. THIS SOFTWARE
IS RELEASED AS "FREEWARE". REDISTRIBUTION IS ONLY ALLOWED IF THE
SOFTWARE IS UNMODIFIED, NO FEE IS CHARGED FOR THE SOFTWARE, DIRECTLY
OR INDIRECTLY WITHOUT THE EXPRESS PERMISSION OF THE AUTHOR.
