Nitro2 readme
-------------
you can find all documentations in the subdir docs.
read the install_eng.htm for a detailed installation help.

the History.htm contains all importend informations for all versions of Nitro2
be sure to read it at last one time, it will help you understanding Nitro2!

Nitro2.htm is the complete documentation of Nitro2 with informations on all services
Nitro2 provides.

addons (like location files) can be found in the addon dir.

if you use Nitro2 you have to report all bugs to 
niewi@nitroforce.de or to ralfn@rocketmail.com

you can always get the newest version of Nitro2 at
nitro.vekoduck.com     (english)
nitro.splatterworld.de (german)

both pages host a messageboard where you can ask question or discuss with others

you can also get me:
icq      25115019
irc      #quake.nfproxy
quakenet #NitroForce

have fun with Nitro2 ...
