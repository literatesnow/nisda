Watcher v1.88 - Copyright (C) 2002-2004 bliP
Web: http://nisda.net
Email: scrag [at] nisda [dot] net
IRC: #nzgames irc.enterthegame.com
Compiled: v1.0: 2002-11-22, v1.88: 2004-11-28

Watcher is a QuakeWorld Server administration program.

Connect to a server and players, serverinfo/localinfo are shown. Ban list
(filter list) is under Server->Server Filter List. To add servers to drop down
box, Tools->Favourite Servers. Right click on players to do things to them.
Tools->Copy Info to copy server IP and server password (not rcon) to clipboard
(for pugs/bvr/bookings). Read below on how to use scripts.
Probably a good idea to read all of this before you get started.

Server
  Site Manager: List of servers
    Add: Type in details and click "Add", if you leave rcon blank you'll be
      prompted for it on connect
    Remove: Select server(s), click "Remove"
    Up: Move server up in list
    Down: Move server down in list
    Group: Servers can be part of groups. You can select many servers to add
      them all to a group
  Connect: Type server address:port and rcon in boxes and press "Connect"
           or choose a server from drop down box
  Disconnect: Press "Disconnect" button
  Refresh: Updates listing
  Server Filter List: Add/Remove filtered IP addresses (ban list)
    Refresh: Updates listing
    Add IP: Type full IP address in box, click "Add IP"
    Remove IP: Select IP address, click "Remove IP"
  Run Script: Runs a script (see Script below)

Tools
  View Today's Log: Open today's (dd-mm-yy-info.log)
  Open Folder: Explore folder Watcher is in
  Copy Info: Copies server IP and server password to clipboard
  Clear Virtual Console: Clears the virtual console

Options
  Auto Refresh: Refresh listing every x ms
  Refresh Interval: How long the wait before the listing is refreshed (in ms)
  Refresh on Virtural Console: Refresh player list whenever a command is entered
    Note that if this is unticked and you enter a command that effects the
    players it will not be shown immediately
  Log Users: Log user name, state, IP and userinfo to dd-mm-yy-info.log
  Log Rcon Change: Log rcon changes from Virtual Console/Script to
    dd-mm-yy-info.log
  Prompt: Prompt before kicking/banning/muting/cuffing a player
  Say Text: Text displayed before the message with kick/ban/say messages
    console: SAYTEXT: Message..
    eg: Say Text is "bliP: " and the message is "hello!"
        would look like: "console: bliP: hello!"
    can use quake name characters to get gold brackets etc
  Say: Prefix say text on say and say kick/ban reason
    If Say is ticked, the reason will be said to the server.
    For example (ticked):
      console: watcher: foo! Stop respawn spamming!
      foo was kicked from the game
      foo left the game with -9 frags
    Otherwise (unticked):
      foo was kicked from the game (foo! Stop respawn spamming! [banned])
      foo left the game with -9 frags
    Note that reason kicks are not available on all servers (qw 2.33 doesn't),
    if reasons aren't displayed tick say
  Custom Copy Info: For a custom Copy Info format
    %ip is replaced with server ip:port and %pw with server password. \ is a
    new line, default is server: %ip\password: %pw
  Minimize To Tray: Minimize to tray
  Show Local Info: List Local Info in Server Info & Local Info box
  Hide Local Info Numbers: Hide localinfo 100[..9999] <map name>
  Use Real IP: On ban, ban the real IP if known and not the connected IP
    (not available on all servers)
  Show Full Name: Display the quake name in the player name column in brackets
  Clone Scan: Display clones in state column
  Extras: Display Cuff and Mute on right-click menu (not available on all servers)

Help
  Help: Display this file
  About: Version and copyright info

Player Listing
  Values will be n/a if unknown (usually caused by player having a full userinfo
  or they're connecting or they're cheating)

  Player Name: Player's name
  Frags: Frag count (only for connected players)
  Skin: Skin (hidden if spectator/connecting)
  Client: Their client (displays all star keys)
  Proxy: Proxy if they use one (Qizmo, Cheapo, NFProxy and Nitro)
  PModel: PModel
  EModel: EModel
  Net IP: The IP address which the client is connecting from
  Real IP: Client's real IP address (not supported by all servers)
  State: P/A - Player Active
         P/C - Player Connecting
         S/A - Spectator Active
         S/C - Spectator Connecting
         ! - Real IP and Net IP don't match (probably using a proxy)
         * - Net IP clone
         ^ - Real IP clone
  UserID: Users' UserID

  - Click player to view userinfo
  - Click column heading to sort list
  - Drag to select more than one player
  - Right Click player (see also, option Say above):
      Kick: Kicks player from server
      Kick (Reason): Kick with a reason (%p will be their quake name)
      Ban: Bans player from server
      Ban (Reason): Ban with a reason (%p will be their quake name)
        Tempban (minutes) - Unban player after a certain time
        Group - Ban player from all servers in this group
      Copy IP: Copy player's IP address to clipboard
      Copy Quake Name: Copy player's Quake Name to clipboard
      Copy User ID: Copy player's User ID to clipboard

Virtual Console
  Type commands in the bottom left box (rcon <pw> is unneeded)
  eg. to use "status" command, type status and hit enter
  - User Up and Down Arrow keys to scroll through previous commands
  - Clicking on Virtual Console gives the input box focus 
  - To copy text, hold down CTRL, highlight with mouse and right click copy

Server Info & Local Info
  Displays server info and local info for the server
  - Right Click name to copy key and value or change value
  - Values marked with * are a best guess as the key is longer than 20
    characters, use the virtual console to view/change these

Player Info
  Select user from Player Listing and it displays their user info
  - Right Click name to copy key and value

Scripts
  Scripts are plain-text files containing rcon commands
  Place scripts in watcher\script with a .ws extension and they will show up
  in the box. Choose a script then press Run button or Run Script button.

  Example Script: duel.ws
    //duel script
    timelimit 0
    fraglimit 0
    map dm6
    maxclients 6
    maxspectators 12
    password none
    spectator_password none
    hostname "Duel Server (dm6)"

  Note:
    every line of the script is read, prefixed with "rcon <rcon_pwd>" and sent
    to the server, // can be used as comments and will be ignored

Status bar
  On the status bar from left to right:
    LU: Last Update time
    Users: total players/max players, total spectators/max spectators,
    active players/connecting players/active spectators/connecting spectators
    Info: map, status, net address, cpu utilization, bandwidth, avg response
      time and packets/frame.
  Bandwidth is an estimate: (((player1 rate) + (playerN rate)) / 1000)
  Assumes max rate of 10000. Rates which are greater than 10000 are trimmed.

Command line options:
  -debug
  This will log all packets and overflows to logs\debug.log
  If Watcher does not work on your server or overflows a lot, use this and
  email me the log. Rcon password is blanked out, you'll need to blank other
  passwords in localinfo etc (do a text find and replace).


Please send all questions, bug reports, comments and suggestions
to the email address provided above.

Disclaimer:
ANY USE BY YOU OF THE SOFTWARE IS AT YOUR OWN RISK. THE SOFTWARE IS
PROVIDED FOR USE "AS IS" WITHOUT WARRANTY OF ANY KIND. THIS SOFTWARE
IS RELEASED AS "FREEWARE". REDISTRIBUTION IS ONLY ALLOWED IF THE
SOFTWARE IS UNMODIFIED, NO FEE IS CHARGED FOR THE SOFTWARE, DIRECTLY
OR INDIRECTLY WITHOUT THE EXPRESS PERMISSION OF THE AUTHOR.

