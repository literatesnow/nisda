OZTF version 1.06        by Mercury

Please visit our new site:    http://ap.qgl.org/mercury/

   Thank you to all those involved in making this modification possible.

   Big thank you to Omicron, Rawhide, Team Fortress and Kombat Teams software.

   Also thank you to Fuh for his client (fuhquake) which allows my testing to by much easier

   For fuhquake client visit:  http://www.fuhquake.net/


For more information please visit: http://ap.qgl.org/mercury/

For bug reports either post them on the above forum 


Email me for further information....    merc_davos@hotmail.com

QWTeamFortress 4 Ever!


How to update:

If you are updating from Team Fortress 2.9 the minimum required to update to Oz Team Fortress is to replace the qwprogs.dat with the one in the current zip and add the 4 dot sprites either to your "/progs" directory in fortress, or they can be added to the pack files.


Updates: 

Version 1.06                Released   12 / 12 / 2002

Fixed changeteam command, now removes detpack and engineer buildings and also brings up the playerclass menu so you can choose a legal class.
Added lights command to toggle lighting (for a bit of fun).
Added t1maxplayers, t2maxplayers, t3maxplayers and t4maxplayers localinfo's to specify the maximum amount of players on each team (this overides info_tfdetect map entity).
Added t1illclasses, t2illclasses, t3illclasses and t4illclassess localinfo's to specifiy the illegal classes on each team (this overides info_tfdetect map entity).

Please check out the website for more info.


Version 1.058               Released   29 / 11 / 2002

Updated EMP grenade, now explodes surrounding rockets and grenades.
break not allowed during prematch time or ceasefire time
Countdown and prematch non integer error fixed
Updated concussion effect (same as tf2.9)
Added changeteam command
Sentries shooting observers fixed

Version 1.04               Released   22 / 10 / 2002

Added flag colour glow to team 1 and 2 flags.
improved changeclass procedure

Updated Hwguy. Cannon spread increased while moving hence reduces damage while moveing.
Updated Pyro. Flamer speed reduced to 700 velocity.

Added soliddet command to toggle solid detpacks
Added prematch localinfo and pmup pmdown commands
Added overtime commands otup and otdown to toggle overtime.
Fixed adminpwd will allow adminlevel bypass (if you become an admin via adminpwd you have full access regardless of server adminlevel)

Added spectator positioning cams (inpulse 2 for item_tfgoals (flags) impulse 3 for info_tfgoals and imp 4 for sentryguns).
Added fade to black, fade from black for demo editting impulse 9 and 0 while specatating

fixed admin commands available to non admins. This may have fixed sbar printing bug
change impulse command for sbar_res

Moved serverinfo n to localinfo

Updated sentry gun.

fixed sentry speed error. (Normal sentry speed was set to fast on level 2 and 3)

Added new algorthym for sentry firing angles. 

The orginal code allowed a 10 degree radius from the direction of the sentry gun to allow an enemy to be fired upon. This means as the distance increased, the less the sentry gun depended on being in the correct position. Up close if you run around the sentry gun it will stop firing and move the gun towards the enemy and refire. This is now dependant on distance of the enemy. The greater the distance the smaller the angle is to make a more realistic targetting system. I will release a spreadsheet showing the firing system graphically.

Version 1.03               Released   3 / 10 / 2002

added duel localinfo 
fixed admin messages printing when other impulses used 
fixed respawn bug 
removed golden localinfo. 

added duel.cfg 

The duel localinfo will give classes full armor on spawn and half their maximum ammo for each ammo type. It also gives them maximum grenades. 

The golden localinfo is no longer needed as overtime is defined by its value being greater then 1. If 0 overtime is off. If 1 overtime is 1 minute, etc. 


Version 1.02               Released   30 / 9 / 2002
 
added modstatus command
fixed admin election bug
fixed (i think) respawn bug
added special alais will respawn player (if above bug occurs this is a backup)
clansetup and reset command updated
clan mode countdown fixed
tfvsdm reload bug fixed

Version 1.0                Released   26 / 9 / 2002 

Fixed soccer goal sound, wasnt full volume around whole level
Added sgfire command, which toggles between firing bullets and lightning :)
(more on that in documentation)
Disallowed sentry building on tflite mode
Modified max_world_pipebombs for 4 teams. Each team is allowed 5 pipebomps, with 2 teams 7 pipebombs as normal. Tf lite has 4 pipes with 4 teams and 5 with 2.
Fixed cuss affect, was too strong on jump
Added pipedelay command to toggle pipebomb delay
Fixed no blips was not printing on no object detected

Verion 0.95
Added sbar movement on setinfo sbs/sbar_size. With a value it can now move sbar from 1 to 10 linebreaks down for added support. Default is 3.
Fixed setinfo sbar_res
Removed Ban (since all it did was kick the player.)
Fixed countdown printing was conflicting with sbar printing.

Version 0.93
Remove speedcheat code detect and kick (doesnt exactly work, it wont change anything)
Improved new admin system. Commands added.
Localinfo adminlevel added
adminlevel 3 allows admins to kick players at all times
adminlevel 2 allows all other commands but are not available during a clan match
adminlevel 1 allows only few commands mainly those that do not alter phsyical gameplay
Added gren print on sbar
Removed equalization
Removed class binding
Fixed overtime golden cap.
Impulses work during fire, no more stickies during (attack_finished > 1) of any weapon except hw cannon because it causes a frame error.
Added pyro RJ!
(mvdsvr rounds off to 1 decimal place, can cause problems with commands especially when testing with zquake server that doesnt round off)
fixed gspeed command error. 
fixed soccer ball physics ( look down and u will kick the ball with less height look up and more height)
fixed soccer goals not working now u can score goals
fixed no cuss affect on jumps
fixed class help working properly now
fixed gas grenade attempted to remove world bug
fixed random teams picking disabled classes bug
fixed sbar now prints scanner objects and range like before
fixed voting after election doesnt work
fixed scout discarding cells
fixed flashlight working while dead and observing
fixed sg too quick, sg has 2 firing modes normal and fast.

Administration:

captured admin check stuff in 1 procedure. "blah!" 

Alias Commands:

about
' and '
commands aliased commands to show information about mod and commands. 

Elect allows anyone to elect for admin in non clan mode / abort election 
yes "vote yes for person electing" 
no "vote no" change vote if already voted yes
flash: added flashlight "impulse for a flashlight much like hl flashlight. You can now see in the dark tehe!" Can only be used it flashlight allowed set by server admin

break command now anyone can stop the countdown, or it executes a votebreak precedure so you can vote to stop the current match 

timeup "increases timelimit by 5 minutes" 
timedown "decreases timelimit by 5" 
fragsup "increases fraglimit by 10" 
fragsdown "decreases by 10" 
tp "cycles through teamplay settings such as tp1, tp 11, tp 21, tp 31, tp 109. Note more tp's to be added" 
clan "turns clanmode on" 

startmatch command: once clan mode is selected you can now type startmtach it will begin a countdown and start the match just like normal. Although theres a timer added to calculate timeleft etc which will print 5min remaining, 1 min, 30sec, 15sec, 10sec and <10sec. 

Backpack : you can now toggle backpacks from normal to backpacks which contain grenades of each type. For instance.. If someone dies with 2 gren1's and 1 gren2 whoever picks up this back will recieve the 2 gren1's and 1 gren2's. Grenades are only set in packs when a player dies. You cannot discard packs with grenades. 

Overtime added: a localinfo golden and overtime added to allow for overtime which is is activated when two or more teams draw.

teamfrags: toggle Team Frags 

fullts: toggle Full Team Score 

reset: Resets all current settings and restarts map. 

clansetup: Sets all current settings for a clan battle and restarts map. With settings such as Teamplay 1, timelimit 40 etc. 

freeze: it freezes platforms doors etc, this is automatically set on during clan matches in spaz4 and canalzon. So now u can actually start spaz4 in clan mode without the restarting map crap. 

fbskins: toggle fbskins "not working in fuhquake i might need to talk to fuh about setting the same fpd in client" 

pointing:  to enable or disable pointing 

enemy: to enable or disable enemy reporting 

silence: command to toggle spectator talk.

flag_emu: replace any TF goals using the old Quake keys 

use_stand: will replace any TF Flags with the new TF War Standard flags. 

grapple: allow/disallow grapple, works on all maps!

sgspeed: toggle the yaw (movement) speed of the sentry gun from fast to normal.

sgfire: toggles between lightning fire and normal bullets

pipedelay: toggles pipebomb delay for demoman

gspeed: Added ground speed command to control the speed of a player when hes on the ground (anti bunnyhop). 

There are 4 choices with the command. 

Normal ground speed (normal qw bh) 
Ground speed = Maximum class speed (Player can not go faster than the maximum speed of his class) 
Ground speed = 1.25 Max class speed ( 1.25 x the maximum speed of his class) 
Ground speed = 1.5 Max class speed ( 1.5 x the maximum speed of his class) 
Ground speed = 2 Max class speed ( 2 x the maximum speed of his class) 


Modes Added:

TFvsDM mode, this mode is a mod I made in a previous mod leading up to this one, which was my actualy first mod made. It involves having Team 2 and Team 4 set as Quake soldiers and nothing else, whilst in Team 1 and Team 3 are normal TeamFortress teams.

TFLite mode: this mode prevents players from using Secondary Grenades such as Nail Grenade. It also prevents ammoboxes being created on dropammo commands. The sole purpose of this mode is to reduce the number of enitities at one time. This in affect reduces the chances of a server crash and is suggest you use it in a large Lan situation.

Highlander mode (there can only be one) as this suggest you can only choose 1 of each class per team. For instance there can only be one scout one soldier etc on the Blue team and the same for any other team. There can also be one random class.


Class leveling:

increased sniper gun reload time
reduce sniper gun damage
Light Incendiary Cannon added. Impulse 6 which is flame thrower is moved to impulse 5. Impulse 6 is now the Light Incendiary Cannon and impulse 7 is the Heavy Incendiary Cannon (heavy being normal) 
The Light Incendiary Cannon takes 2 rockets ammo per shot, travels at a faster speed (velocity 800), reload time reduced (0.9), Damage reduced (32 + (random * 10)). 
Heavy Incendiary Cannon (normal) takes 3 ammo, velocity 600, reload time 1.2 and damage increased (50 + (random * 20)). 

The after affects damage (burning) should be the same for each weapon.
flame thrower distance increased (previously distance was calculated 600 velocity per flame at 0.125 seconds a flame. Now 800 velocity per flame) 
medic now has concusion grens increased to 3 on spawn. 
engineer has also increased to 3 of each grenade type. 
sniper flares reduced to 2 

Bug Fixes:

Last major update was bug with looping impulses. 

After an impulse is selected out of 200 impulses it is suppose to exit the loop and therefore allow other impulses to be activated on next frame. Problem was it kept on going and sometimes looping numerous times. This was fixed so once each individual procedure has be activated by the impulse it returns immediately 
Some may notice the difference others wont. 
Fixed error in spy printing message not correctly printed. 
Fixed "finished reload" printing messages were printing to an area which most new clients do not support. 
Fixed sg aiming will now aim correctly at the client.
Fixed clan mode
Fixed timelimit in normal and clan mode. (timelimit is not accumulated in clan mode until the match has started)

Other:
removed fov setting "no more drop fov needed where tf sets fov to 90 after spawning" 
I also removed TF_ID and the settings to old clients as ghosts. 
Locked game was removed also as it wasnt being used and it soley required tf_id.
Menus change to allow spy to change skin to base in TFvsDM mode. Prints updated.
The sentry gun is now more accurate and faster. Thanx to Rawhide who created a more effiecient algorithym that allows each condition to be tested quicker and more efficient. I revised the code a bit and I hope to add a more intelligent sentry gun. 
Made detpacks non solid, and altered disarming. 
Detpack is no longer solid, this in istelf does create a problem with disarming the detpack. 

Added map changing command which shows a tf like menu which u can select the map u can change to. Its pretty caw how it works and u can list probably over 100 maps in the server and use the menu to go through all of them until u select a map u wish to change to. Unfortunately due to printing constraints you have to enter to read the list and press and then exit to select a map using the associate impulse.

added centerprint for clan games with team names. " new motd added for clan games where it gives centerprints team1 vs team2" 
added cap timing speedcature. Calculated from time flag taken to time flag captured.
made detpack non solid, and altered disamring
changeclass will work with deathmatch 1 - 5 //tf requires deatmatch 3
observer can now walk around unless clanmode is on
removed birthday code
added freeze for spaz4 & canalzon
added freeze localinfo
button2 enabling autoteam removed.
autoteam localinfo removed

Entity fixes: 
Spamming ammoboxes with an alais can leave lots wastefull empty entities. There is a current bug in TF which doesnt allow ammoboxes to be removed correctly. Omicron had also noticed this and recreated a new algorithym that works properly. This was implemented and revised a bit, but great credit to Omircon. 
This means when you spam dropammo it will actually remove calculate the total amount of ammoboxes in the world like pipebombs when it reaches a maximum constant set, it removes first ammobox it finds in order of entities. 
Added coloured sniper dots
active number of ngs reduce to 1

Using the sbar source from OmiTF thanx to the much appreciated work of Omicron who created a different printing method for sbar. 

Removed prematch time: 
Prematach time has been removed and replaced by the new startmatch system, a command needed by admin. I might change admin to make it so each team can have a specified amount of admins (1 or 2) and he or she controls when the team is ready. 

added ball (for future soccer mode) to add a ball in a map you have to modify the maps entities and add a item_ball, with an origin on the map


Server commands (Localinfos)

to set type (localinfo "command" "value" in your server)

current localinfos:

count
golden
overtime
gibs
grenpacks


minrate : sets the minimum rate a client can have 
maxrate : sets the maximum rate a client can have 
allowadmin : allows or disallows admins with election procedure 
count : specifies the length of countdown with the startmtach command 
gspeed : you can now set the ground speed to a precise amount witout using the toggable command. 

The following locainfos require map restart
freeze : to freeze the map on start 
tfvsdm : set tfvsdm mode on map start 
tflite : set tflite mode on map start. 
highlander : set highlander mode
flashlight : allow flashlight
fastsentry : set fast sentry yawspeed


removed localinfo    Equivilant localinfo
s                      spy_inv
g                      grapple
t                      teamfrags
fts                    fullteamscore
c                      clan
ws                     use_standard
fe                     flag_emulation
cr_sc                  cr_scout
cr_sn                  cr_sniper
cr_so                  cr_soldier
cr_de                  cr_demoman
cr_me                  cr_medic
cr_hw                  cr_hwguy
cr_py                  cr_pyro
cr_sp                  cr_spy
cr_en                  cr_engineer
cr_ra                  cr_random
apw                    adminpwd
autoteam

the above localinfos were removed because the local commands could only modify one localinfo at a time otherwise it would cause procedural problems, or unecessary addition of code. 