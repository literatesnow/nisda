Oz TeamFortress  �  Mercury

http://ap.qgl.org/mercury/


Version 1.45 Released 1/ 07 / 2003

Updates:
--------- 
Added mvdsv function support, including many features like autorecording.

Added Half life map entities (rotating doors under development).


Additions:
-----------

mvd-server commands added, see mvdsv-features.txt
mvd-user commands added, see mvd-cmdfeatures.txt

frjump command to toggle forward rocket jump
Observer menu choice, impulse 6 to observe.
New third person camera angle!
Updated flag cam (will follow player who picks up the flag)

Added support for TFC maps and CS maps. de_maps will add
bomb support. cs_maps allow for hostage support.
It also contains many addition entities like func_breakables etc.


Showstats command added, shows your individual stats including damage.


Localinfos Added:
------------------
Localinfo votespercentage added to allow the ability to set the minimum or maximum percentage of votes, to enable someone to gain admin status.
Localinfo demo_auto_left added to set the number of matches you wish to autorecord.



Fixes:
-------
-message printing for all admin commands
-hwguy concussion affect reduced (three times less)
-practice mode updated, flags, resupply's and cap points work
-showfrag print positioning
-cams
-changeteams bug
-current_menu during round_over
-autoteam fix, balance.
-sbar in rounds, prints time to all clients not just players
-reload time, reloading dependant on recoil time like tf2.9
-cs entities - bombsite
-tfc entities
-fixed hwguy water bug
-light dimm match start
-soccer goals working correctly (requires new map)
-lots of other stuff, I cannot remember all

Removed:
---------
pickmap command
voicemenus and all voice commands
removed the voice sounds

How to update:
---------------

If you are updating from Team Fortress 2.9 (or 2.8) the 
minimum required to update to Oz Team Fortress is to replace 
the qwprogs.dat with the one in the current zip and add the sprites, and models your "/progs" directory in fortress, or they can be added to the pack files.


Please visit our new site:    http://ap.qgl.org/mercury/

   Thank you to all those involved in making this modification possible.
   Big thank you to Omicron, Team Fortress and Kombat Teams software.
   Also thank you to Fuh for his client (fuhquake) which makes my testing much easier.


For fuhquake client visit:  http://www.fuhquake.net/

For more information please visit: http://ap.qgl.org/mercury/

For bug reports either post them on the above forum 


Email me for further information....    merc_davos@hotmail.com

QWTeamFortress 4 Ever!


