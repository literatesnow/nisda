Spot v1.0 - Partly Copyright (C) 2004 bliP
Web: http://nisda.net
Email: fiend [at] nisda [dot] net
IRC: #nzgames irc.enterthegame.com

Description:
Battlefield 1942 modification, adds Eve Of Destruction's Loach helicopter to
all battlefield 1942 maps (apart from Coral Sea).

Installation:
Extract spot into the \Battlefield 1942\Mods directory.

Other changes:
- Loach Fire/AltFire in the pilot/passenger seat calls artillery
- Loach/Artillery wont explode if left alone for 15 mins
- Loach/Artillery (re)spawns immediately
- Artillery has 500 shells
- Artillery reloads faster
- Artillery cameras last for 15 mins
- Wrench is super

The Loach has been borrowed from Eve Of Destruction (http://www.eodmod.com)
and fully belongs to the original author. As this mod is very small and is
aimed for single player, I hope I didn't tread on any toes by using it.

