TeamFortress SoundTrigger Sounds
Collected by bliP
Web: http://blip.cjb.net
Email: blip56@yahoo.com
4 February 2002

Extract to quake\id1\sound\reports