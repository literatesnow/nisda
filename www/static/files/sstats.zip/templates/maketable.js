// maketable.js
// by Erik Selberg <selberg@cs.washington.edu>
// makes a table that allows for dynamic redrawing of sorts on columns
// assumes layers in Netscape 4.0
// modification by Boris Usievich <borisu@kapella.gpi.ru>
// support for IE 4.x-5.x 
// some CSS formating

var sortindex = 0;
var sortdir = 0; // 0 = low -> high, 1 = high -> low
var userAgent = navigator.appName + " " + navigator.appVersion;

var ns40 = (userAgent.substring(0, 11) == "Netscape 4.") ? 1 : 0;
var ie50 = (userAgent.indexOf("MSIE 5")>0) ? 1 : 0;
var ie40 = (userAgent.indexOf("MSIE 4")>0) ? 1 : 0;
var ie = ie40 || ie50;

var oneshot_stats;
var oneshot_stats_header;
var oneshot_stats_print;

// attaches properties to a layer (NS) or div (IE)
function bindLayer(stats, stats_header, stats_print, tablename) {
  if (ie) {
    obj = document.all.tags("div").item(tablename);
    obj.stats = stats;
    obj.stats_header = stats_header;
    obj.stats_print = stats_print;
  } else
  if (ns40) {
    window.document.layers[tablename].stats = stats;
    window.document.layers[tablename].stats_header = stats_header;
    window.document.layers[tablename].stats_print = stats_print;   
  } else {
    oneshot_stats = stats;
    oneshot_stats_header = stats_header;
    oneshot_stats_print = stats_print;
  }
}


function colCompare(a, b) {
  var rv;
  if (a[sortindex] == b[sortindex])
    rv = 0;
  else 
    rv = (a[sortindex] > b[sortindex]) ? 1 : -1;
  //     alert("Comparing " + a[0] + "(" + a[sortindex] + ")" + " > " + b[0] + "(" + b[sortindex] + ")" + " at " + sortindex + " == " + rv);
  return sortdir ? rv : -rv;
}


function formatString(s, form) {
  if (form == "percent") {
    s *= 100;
    s = Math.round(s);
    return s + "%";
  } else { // "int" "string" "default"
    return s;
  }
}

function totalVal(s, form) {
  if (form == "percent" || 
      form == "string" || 
      form == "int_nototal") {
    return "";
  } else { // "int" or default
    return s;
  }
}


// stats - array of statistics
// stats_header - header for statistics
// stats_print - way to print each column
// doc - the document we're writing to... should be a window
// tablename - name for layer we're writing to
// n - column clicked on        

function mt(tablename, n) {
  var stats;
  var stats_header;
  var stats_print;
  var align;
  var celltype;
  var celldata;
  var tabletext = "";

  if (ie) {
    obj = document.all.tags("div").item(tablename);
    stats =            obj.stats;
    stats_header =     obj.stats_header;
    stats_print =      obj.stats_print;
  } else 
  if (ns40) {
    stats =            window.document.layers[tablename].stats;        
    stats_header =     window.document.layers[tablename].stats_header; 
    stats_print =      window.document.layers[tablename].stats_print;  
  } else {
    stats =            oneshot_stats;        
    stats_header =     oneshot_stats_header; 
    stats_print =      oneshot_stats_print;  
  }

  var totals = new Array(stats_header.length);
  totals[0] = "Total";
  for (j = 1; j < totals.length; j++)
    totals[j] = 0;

  if (n<0) {   
    sortdir = 0;
    n = -n
  } else {
    sortdir = (n == sortindex) ? !sortdir : 0;
  }
  sortindex = n;

  if (ns40) tabletext += "<center>";
  tabletext += "<table border=1 cellspacing=0 cellpadding=2 width=\"80%\">\n";
  tabletext += "<tr>\n";

  stats.sort(colCompare);
  for (j = 0; j < stats_header.length; j++) {
    tabletext += "<th class=h>";
    if (ie) 
      tabletext += "<a class=h href=\"#"+tablename+j+"\" onClick='makeTable(document,\"" + tablename + "\"," + j + ");'>"+ stats_header[j] + "</a>";
    else
    if (ns40)
      tabletext += "<a class=h href=\"#here\" onClick='return makeTable(window.document.layers[\""+ tablename + "\"].document, \""+ tablename+ "\", "+ j+ ");'>"+ stats_header[j] + "</a>";
    else
      tabletext += stats_header[j];
    tabletext += "</th>";
  }
  tabletext += "</tr>\n";
  for (i = 0; i < stats.length; i++) {
    tabletext += "<tr>\n";
    for (j = 0; j < stats[i].length; j++) {
      align = (j == 0) ? "center" : "right";
      celltype = (j == 0) ? "th" : "td";
      celldata = formatString(stats[i][j], stats_print[j]);
      if (j == n && (ns40 || ie))
	celldata = "<span class=y>" + celldata + "</span>";
      tabletext += "<"+ celltype + " align=" + align + ">" + celldata +
		"</"+ celltype + ">\n";
      if (j != 0)
	totals[j] += stats[i][j];
    }
    tabletext += "</tr>\n";
  }
  tabletext += "<tr>\n";
  for (j = 0; j < totals.length; j++) {
    align = (j == 0) ? "center" : "right";
    celltype = (j == 0) ? "th" : "td";
    celldata = (j == 0) ? "<span class=b>Total</span>" : totalVal(totals[j], stats_print[j]);
    tabletext += "<"+ celltype+ " align="+ align+ ">"+ "<span class=o>"+ 
	      celldata+ "</span>"+ "</"+ celltype + ">\n";
  }
  tabletext += "</table>";
  if (ns40) tabletext += "<p></center>" 
  return tabletext;
}         

var maketables ="";
var divs;

function makeTable(doc, tablename, col) {
  if (ie && col<0) { //first time
    maketables += "obj=divs.item(\"" +tablename+ "\");"
    maketables += "obj.innerHTML=mt(\"" +tablename+ "\"," +col+ ");"
  } else if (ie) {
    place = doc.all.tags("div").item(tablename);
    place.innerHTML = mt(tablename, col);
  } else {
    doc.write( mt(tablename, col) );
    doc.close();
  }
  return false;
}

function MakeAllTables()
{
  divs=document.all.tags("div");
  eval(maketables);
}
