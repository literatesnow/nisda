this is a pure bugfix release. you need the Nitro2_050.zip for it to run.
just unzip Nitro2_050.zip in a directory and copy the newer ones from this zip over it.

get Nitro2 at:

nitro.vekoduck.com
nitro.splatterworld.de
