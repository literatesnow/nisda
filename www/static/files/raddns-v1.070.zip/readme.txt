RadDNS v1.070 - Copyright (C) 2003-2005 bliP
Web: http://nisda.net
Email: spawn [at] nisda [dot] net
IRC: #nzgames irc.enterthegame.com
Compiled: v1.0: 2003-12-21, v1.070: 2005-02-19

RadDNS is a mini DynDNS client (http://www.dyndns.org/). It was created because
the existing clients either didn't detect my IP correctly, crashed alot or
weren't free. If you find it useful or want additional features, feel free to
contact me.

This client is about as simple as it gets:
-web based IP detection only (first IP found on page will be used)
-dyndns only
-wildcard off
-settings saved in INI file (so you can copy whole directory anywhere)
-saved password is encrypted

Interface:
O  Options (toggles)
?  About (toggles)
.. Minimize
X  Quit

Options:
-Address: this is your DynDNS address
-User Name: this is your DynDNS user name
-Password: this is your DynDNS password
-Web IP: URL to get your IP from
 try the ones below, push test and make sure it's your IP
-Use Activity.log: Log everything
-Auto Start: Hide to tray on startup and start
-Show Images: show/hide background image

Web IP Addresses:
http://checkip.dyndns.org/
http://ip.nefsc.noaa.gov/
http://www.whatismyip.com/
http://nzadsl.co.nz/myip.pl
http://speed.comnet.co.nz/cgi-bin/printenv
-If you're in New Zealand try the .nz ones first

Shortcut Keys:
ALT+S - Start/Stop
ALT+O - Options
ALT+A - About
Up/PgUp - Scroll Up
Down/PgDn - Scroll Down

Other:
-Click the IP to copy it to clipboard.
-Skip: X is the number of times the IP is the same.

Return messages (full at http://www.dyndns.org/developers/specs/return.html):
-badauth: The username or password specified are incorrect.
-good: The update was successful, and the hostname is now updated.
-nochg: The update changed no settings, and is considered abusive. Additional
 nochg updates will cause the hostname to become blocked.
-notfqdn: The hostname specified is not a fully-qualified domain name (not in
 the form hostname.dyndns.org or domain.com).
-nohost: The hostname specified does not exist (or is not in the service
 specified in the system parameter)
-!yours: The hostname specified exists, but not under the username specified.
-abuse: The hostname specified is blocked for update abuse.

Images:
-Main background image is of Elin Grindemyr which can be retrieved from
 http://www.slitz.se
-Icon unknown

Please send all questions, bug reports, comments and suggestions
to the email address provided above.

Disclaimer:
ANY USE BY YOU OF THE SOFTWARE IS AT YOUR OWN RISK. THE SOFTWARE IS
PROVIDED FOR USE "AS IS" WITHOUT WARRANTY OF ANY KIND. THIS SOFTWARE
IS RELEASED AS "FREEWARE". REDISTRIBUTION IS ONLY ALLOWED IF THE
SOFTWARE IS UNMODIFIED, NO FEE IS CHARGED FOR THE SOFTWARE, DIRECTLY
OR INDIRECTLY WITHOUT THE EXPRESS PERMISSION OF THE AUTHOR.

-bliP
"Because I Can." :]

