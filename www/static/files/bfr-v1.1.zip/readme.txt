Battlefield Reconnecter v1.1 - Copyright (C) 2004 bliP
Web: http://nisda.net
Email: fiend [at] nisda [dot] net
IRC: #nzgames irc.enterthegame.com
Released: 2004-08-16 to 2004-09-10

BFR lets you reconnect to a Battlefield server by clicking on Add Server,
then Join in the Multiplayer menu.

For Battlefield 1942:
-Copy bf42r.exe into your Battlefield 1942 directory
-In ASE, Tools -> Options..., Games, Battlefield 1942, Program Location then
 change BF1942.exe to bf42r.exe
-For any shortcuts, in the Target box, change BF1942.exe to bf42r.exe

For Battlefield Vietnam:
-Copy bfvr.exe into your Battlefield Vietnam directory
-In ASE, Tools -> Options..., Games, Battlefield Vietnam, Program Location
 then change BfVietnam.exe to bfvr.exe
-For any shortcuts, in the Target box, change BfVietnam.exe to bfvr.exe

How it works:
It takes the IP:Port from +joinServer on the command line then modifies
game.setDefaultIp in GeneralOptions.con and starts Battlefield as normal.

FAQ:
Q. Does it work with PunkBuster?
A. Yes. BFR does nothing to get in the way of PunkBuster as it calls
   Battlefield instead of replacing it.

Q. I'm a paranoid mofo, are you going to steal my megahertz?
A. Of course not. If you really want to see everything that BFR does, download
   FileMon, RegMon and TDIMon from http://www.sysinternals.com/

Q. How do I get this to work with GameSpy?
A. Uninstall GameSpy, download and install ASE from http://www.udpsoft.com/
   then follow the ASE instructions above.

Other:
On a side note, I've tried to make the file size as small as possible. The
program code is 3KB, without using an EXE compressor or requiring any external
DLLs. The remaining 4KB is used by the icon for a grand total of exactly 7KB.
Due to file alignment there's around 256 bytes of wasted space which I had to
turn into something useful.

Please send all questions, bug reports, comments and suggestions
to the email address provided above.

Disclaimer:
ANY USE BY YOU OF THE SOFTWARE IS AT YOUR OWN RISK. THE SOFTWARE IS
PROVIDED FOR USE "AS IS" WITHOUT WARRANTY OF ANY KIND. THIS SOFTWARE
IS RELEASED AS "FREEWARE". REDISTRIBUTION IS ONLY ALLOWED IF THE
SOFTWARE IS UNMODIFIED, NO FEE IS CHARGED FOR THE SOFTWARE, DIRECTLY
OR INDIRECTLY WITHOUT THE EXPRESS PERMISSION OF THE AUTHOR.

