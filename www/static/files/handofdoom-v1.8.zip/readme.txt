HandOfDoom v1.8 - Copyright (C) 2004-2005 bliP
Web: http://nisda.net
Email: fiend [at] nisda [dot] net
IRC: #nzgames irc.enterthegame.com
Released: 2004-12-09, 2005-03-09

HandOfDoom places death bubbles in certain areas of the map,
specifically around uncappable bases to prevent spawn camping
to some degree.

In Battle of Britain, infantry take damage inside enemy hangers
which will stop map hacks and also players cannot enter enemy
vehicles except planes. British engineer's spanner also has more
power.

For Lost Village CTF mode, the crate opposite the flag in the 
coalition base does not give out grenades and C4 explodes after
30 seconds if left alone. Also added villa flag and removed M82.

These are server side modifications, clients do not need these
files.

\Battlefield 1942\Mods\bf1942:
  Battle_of_Britain_001.rfa

\Battlefield 1942\Mods\DC_Final:
  Gazala_001.rfa
  DC_Al_Nas_001.rfa
  DC_Al_Nas_Day2_001.rfa
  DC_Basrahs_Edge_001.rfa
  DC_Battle_of_73_Easting_001.rfa
  DC_DesertShield_001.rfa
  DC_DustBowl_001.rfa
  DC_First_Light_001.rfa
  DC_LostVillage_001.rfa
  DC_LostVillage_nopara_001.rfa
  DC_Oil_Fields_001.rfa
  DC_Twin_Rivers_001.rfa
  DC_Urban_Siege_001.rfa
  DC_Weapon_Bunkers_001.rfa
  El_Alamein_001.rfa
  El_Alamein_Day2_001.rfa
  El_Alamein_Day3_001.rfa
  Stalingrad_001.rfa

