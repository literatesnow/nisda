Scorched Earth 2 server configuration (203.96.92.69:27500)
Last Updated: 2003/2004, packaged on 20 January 2007.

- bliP 
Web: http://nisda.net
Email: scrag [at] nisda [dot] net

Required files (What - URL - Extract/Place in directory):
MVDSV QuakeWorld Server - http://mvdsv.sourceforge.net/ - /se2/
Quake's pak0.pak - ftp://ftp.idsoftware.com/idstuff/quake/quake106.zip and quake108.zip - /se2/id1/
Quake's pak1.pak - From your legal copy of Quake - /se2/id1/
TeamFortress pak files - http://www.planetfortress.com/teamfortress/ - /se2/fortress/
TeamFortress maps - http://blip.qwplayers.org/tfmaps/ - /se2/fortress/maps/

Main settings are in /se2/id1/server.cfg and edit /se2/id1/pwd.cfg to change rcon. Run mvdsv in /se2/ to start the server.
