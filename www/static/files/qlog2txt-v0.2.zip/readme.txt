qlog2txt v0.2 - Copyright (C) 2001-2004 bliP
Web: http://nisda.net
Email: scrag [at] nisda [dot] net
IRC: #nzgames irc.enterthegame.com
Compiled: 2001-06-01, 2007-01-20

Description:
Convert extended ASCII in Quake's qconsole.log into readable plain text.

qconsole.log is a text file containing all the text from the Quake
console. You can make qconsole.log by running Quake (GlQuake, WinQuake,
Quakeworld etc) with the -condebug parameter. eg. qwcl.exe -condebug
qconsole.log will then be created in the game directory (qw/fortress etc).

Usage: <input file> <output file> <all | chat | nochat>

Or:
1) Run qlog2txt
2) Enter full path to source file, quotes for long filenames are
   unneeded.  eg. c:\quake\id1\qconsole.log
3) Enter full path to destination file, quotes unneeded again.
   eg. c:\quake\logs\01 06 2001.log
4) Choose conversion type All, Chat only or No chat (enter a c or n).
   All - Converts everything to destination file.
   Chat only - Only converts player chat and team chat to destination
               file.
   No chat - Converts everything but player chat and team chat (frags,
             deaths, score etc) to destination file.

Compiling:
gcc -o qlog2txt qlog2txt.c

Please send all questions, bug reports, comments and suggestions
to the email address provided above.

