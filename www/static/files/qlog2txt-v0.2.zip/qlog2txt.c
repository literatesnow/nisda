/*
  Copyright (C) 2001-2004 Chris Cuthbertson

  This file is part of qlog2txt.

  qlog2txt is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  qlog2txt is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with qlog2txt; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <string.h>

void NormalizeText (char *name);

int main(int argc, char *argv[])
{
  FILE *infile = NULL;
  FILE *outfile = NULL;
  char s[2048];
  int mode = 0;
  int i = 0;
  
  printf("qlog2txt v0.2 - Copyright (C) 2001-2004 bliP (http://nisda.net)\n");

  for (i = 0; i < argc; i++) {
    if ((!strcmp(argv[i], "--help") || !strcmp(argv[i], "/?"))) {
      printf("Quake text to plain text\nUsage: <input file> <output file> <all | chat | nochat>\n");
      return 1;
    }
  }

  if (argc == 4) {
    infile = fopen(argv[1], "rb"); //read the file as binary because EOF can be written anywhere
    if (!infile) {
      printf("Couldn't open input file %s\n", argv[1]);
      return 2;
    }

    outfile = fopen(argv[2], "w");
    if (!outfile) {
      printf("Couldn't write to output file %s\n", argv[2]);
      return 3;
    }

    if (!strcmp("all", argv[3]))
      mode = 1;
    else if (!strcmp("chat", argv[3]))
      mode = 2;
    else if (!strcmp("nochat", argv[3]))
      mode = 3;
    else {
      printf("Bad mode %s\n", argv[3]);
      return 4;
    }
  }
  else {
    printf("\nCTRL+C to quit\n");

    while (!infile) {
      printf("Enter input file: ");
      fgets(s, sizeof(s), stdin);
      i = strlen(s);
      if (i > 0) {
        s[i - 1] = '\0';
      }
      if (s[0])
        infile = fopen(s, "rb");
      if (!infile)
        printf("Couldn't open input file %s\n", s);
    }

    while (!outfile) {
      printf("Enter output file: ");
      fgets(s, sizeof(s), stdin);
      i = strlen(s);
      if (i > 0) {
        s[i - 1] = '\0';
      }
      if (s[0])
        outfile = fopen(s, "w");
      if (!outfile)
        printf(" Couldn't write to output file %s\n", s);
    }

    while (!mode) {
      printf("Enter mode <all | chat | nochat>: ");
      fgets(s, sizeof(s), stdin);
      i = strlen(s);
      if (i > 0) {
        s[i - 1] = '\0';
      }
      if (!strcmp("all", s))
        mode = 1;
      else if (!strcmp("chat", s))
        mode = 2;
      else if (!strcmp("nochat", s))
        mode = 3;
      else
        printf(" Bad mode %s\n", s);
    }
  }

  printf("\nProcessing...");
    
  i = 0;
  while (!feof(infile)) {
    if (i % 100 == 0)
      printf(".");
    fgets(s, 2048, infile);
    if ((mode > 1) && (!strstr(s, "\xba") && (mode == 2)) || (strstr(s, "\xba") && (mode == 3))) //character \xba is red text ":"
      continue;
    NormalizeText(s);
    fprintf(outfile, "%s\n", s);
    i++;
  }

  fclose(infile);
  fclose(outfile);

  printf("\nWrote %i lines\n", i);

  return 0;
}

char qfont_table[256] = {
	'\0', '#', '', '#', '#', '.', '#', '#',
	'#', 9, ' ', '#', ' ', ' ', '.', '.',
//	'#', 9, 10, '#', ' ', 13, '.', '.',
	'[', ']', '0', '1', '2', '3', '4', '5',
	'6', '7', '8', '9', '.', '<', '=', '>',
	' ', '!', '"', '#', '$', '%', '&', '\'',
	'(', ')', '*', '+', ',', '-', '.', '/',
	'0', '1', '2', '3', '4', '5', '6', '7',
	'8', '9', ':', ';', '<', '=', '>', '?',
	'@', 'A', 'B', 'C', 'D', 'E', 'F', 'G',
	'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O',
	'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W',
	'X', 'Y', 'Z', '[', '\\', ']', '^', '_',
	'`', 'a', 'b', 'c', 'd', 'e', 'f', 'g',
	'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',
	'p', 'q', 'r', 's', 't', 'u', 'v', 'w',
	'x', 'y', 'z', '{', '|', '}', '~', '<',

	'<', '=', '>', '#', '#', '.', '#', '#',
	'#', '#', ' ', '#', ' ', '>', '.', '.',
	'[', ']', '0', '1', '2', '3', '4', '5',
	'6', '7', '8', '9', '.', '<', '=', '>',
	' ', '!', '"', '#', '$', '%', '&', '\'',
	'(', ')', '*', '+', ',', '-', '.', '/',
	'0', '1', '2', '3', '4', '5', '6', '7',
	'8', '9', ':', ';', '<', '=', '>', '?',
	'@', 'A', 'B', 'C', 'D', 'E', 'F', 'G',
	'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O',
	'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W',
	'X', 'Y', 'Z', '[', '\\', ']', '^', '_',
	'`', 'a', 'b', 'c', 'd', 'e', 'f', 'g',
	'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',
	'p', 'q', 'r', 's', 't', 'u', 'v', 'w',
	'x', 'y', 'z', '{', '|', '}', '~', '<'
};

//this function is from quake source
void NormalizeText (char *name)
{
	unsigned char	*e;

	for (e = (unsigned char *)name; *e; e++) 
		*e = qfont_table[*e];
}
